<?php
include('includes/sections/header.php');

//lists();
echo "hello";

include('includes/sections/footer.php');
?>