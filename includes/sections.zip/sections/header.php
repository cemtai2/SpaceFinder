<?php
include('functionlist.php');
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>SpaceFinder</title>
    <link rel='stylesheet/less' type='text/css' href='styles/stylesheet.less' />
    <link rel='stylesheet' type='text/css' href='styles/fonts.css'>
    <script src="js/less.js" type="text/javascript"></script> 
    <script src="js/script.js" type="text/javascript"></script> 
		<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
  </head>

<body">
  <header>
		<h1>
  		<a href='http://localhost/SpaceFinder/'>SpaceFinder.com</a>
		</h1> <br />
		
    <nav>
    	<a onclick='visSwitch("addForm");'>Add New</a>
      <a href='list.php'>View</a>
      <a onclick='visSwitch("about");'>About</a>
      <a onclick='visSwitch("howTo");'>How To</a>
		</nav>
	</header>
