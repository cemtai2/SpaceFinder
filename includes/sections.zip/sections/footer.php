  <footer>
  	<a href=''>Home</a> <br />
    <a href=''>Edit</a>
  </footer>
</body>

</html>